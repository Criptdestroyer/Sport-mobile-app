package com.aemiralfath.league.model.response

import com.aemiralfath.league.model.item.TeamItem

data class TeamResponse(
    val teams: ArrayList<TeamItem>
)